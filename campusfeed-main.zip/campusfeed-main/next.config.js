/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['localhost', 'nit-rourkela-feed.vercel.app'],
  },
}

module.exports = nextConfig
